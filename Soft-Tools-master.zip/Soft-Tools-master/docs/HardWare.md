# HardWare Tools


## 开发工具

- [Quartus](https://www.altera.com.cn/downloads/download-center.html)

- [ISE](https://www.xilinx.com/products/design-tools/ise-design-suite.html)

- [EDK](http://www.tianocore.org/edk2/)

- [Keil MDK](http://www.keil.com/)

- [IAR](https://www.iar.com/iar-embedded-workbench/)

- [KiCad EDA](http://kicad-pcb.org) 开源

## 实用参考
