# Web
Web Tools


## 在线工具

- [Slides Code Highlighter](https://romannurik.github.io/SlidesCodeHighlighter/) 在线代码增加高亮工具

- [Regexr](http://www.regexr.com/) & [regexper](https://regexper.com/)

- [BASE64](http://www1.tc711.com/tool/BASE64.htm)

- [kjson](http://www.kjson.com/) & [codeformat](http://tool.oschina.net/codeformat/json)

- [oschina在线工具](http://tool.oschina.net/)

- [OnlineCorrection](http://www.onlinecorrection.com/) 在线英语Check

- [Grammarly](https://www.grammarly.com/)

- [在线工具](http://tool.lu/)

- [在线测试工具箱](http://www.androidstar.cn/在线测试工具箱/)  px dp sp mm pt in在线转换计算工具, 二维码生成等实用工具

## 实用推荐  

- [Web前端导航](http://www.alloyteam.com/nav/)






