# NFC

NFC Tools


## NFC APK

- nfc-tagwriter

- [nfc-taginfo](http://sj.qq.com/myapp/detail.htm?apkName=at.mroland.android.apps.nfctaginfo) 

- [nfc-tasks](http://sj.qq.com/myapp/detail.htm?apkName=com.wakdev.nfctasks)

- [nfc-tools-pro](http://sj.qq.com/myapp/detail.htm?apkName=com.wakdev.nfctools.pro)

- NFC Spy

- APDU Sender

- [NFCCard](http://android.myapp.com/myapp/detail.htm?apkName=com.sinpo.xnfcmpl)

- [碰碰米](http://sj.qq.com/myapp/detail.htm?apkName=me.pengpeng.ppme)

- [极控者智能戒指](http://android.myapp.com/myapp/detail.htm?apkName=com.jakcom.timer)



## 实用参考
