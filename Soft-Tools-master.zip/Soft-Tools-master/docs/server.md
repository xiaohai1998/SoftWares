


## Intellij IDEA 实用插件
- [mybatis-generator](https://gitee.com/rohou/mybatis-generator)
- [MyBatis-Plus](https://mp.baomidou.com/) 
- [Mybatis-PageHelper](https://github.com/pagehelper/Mybatis-PageHelper)
