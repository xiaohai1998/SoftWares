# Test
Test Tools

## 常见自动化测试工具

- [Appuim](http://appium.io/) ，[源码](https://github.com/appium)

- UIAutomator

- Instrumentation 

- Robotium 

- [Selendroid](https://www.gitbook.com/book/lihuazhang/selendroid/details)

- [ynm3k](https://github.com/douban/ynm3k ) 

- [Subliminal](https://github.com/inkling/Subliminal)

- [KIF](https://github.com/kif-framework/KIF)(Keep it Functional)

- [EarlGrey](https://github.com/google/EarlGrey)（Google开源）

- [Calabash](https://github.com/calabash)

- [Frank](http://www.testingwithfrank.com/)

- [Athrun](http://code.taobao.org/p/athrun/wiki/index/)（淘宝）

- [Macaca](https://macacajs.com/) （阿里）

## GameTest

- [sikuli](http://www.sikuli.org)
- [GAutomator](https://github.com/Tencent/GAutomator)

## 测试工具

> Socket测试工具

- [SocketTest](http://sockettest.sourceforge.net/) Java Socket测试工具
- [sokit](https://sokit.soft32.com/) TCP/UDP 测试（调试）工具 
- [Hercules SETUP utility](https://www.hw-group.com/software/hercules-setup-utility)


## 实用参考  





