# Dep AI Links
AI Links

# Webs
- [towardsdatascience](https://towardsdatascience.com)
- [机器之心](https://www.jiqizhixin.com)
- [handong1587](https://handong1587.github.io/index.html)

# Asesome

## [Asesome AI](https://github.com/skyseraph/awesome-projects/blob/master/doc/ai.md)

## [Asesome AI Dataset](https://github.com/skyseraph/awesome-projects/blob/master/doc/ai_dataset.md)


